[![Linux](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/Linux/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/macOS/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/Windows/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/MinGW/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/Android/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncJugiMapParallaxScrolling/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncJugiMapParallaxScrolling/actions?workflow=CodeQL)

# ncJugiMapParallaxScrolling
A nCine port of the [JugiMap](http://jugimap.com) [ParallaxScrolling](https://github.com/Jugilus/JugiMapFramework) demo by [Jugilus](https://github.com/Jugilus).

The JugiMap Framework is distributed under the [MIT License](https://github.com/Jugilus/JugiMapFramework/blob/master/LICENSE) and is Copyright (c) 2019 Jugilus.
